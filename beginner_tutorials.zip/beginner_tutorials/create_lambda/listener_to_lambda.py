#!/home/keplerc/anaconda3/bin/python
# Software License Agreement (BSD License)
#
# Copyright (c) 2008, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Willow Garage, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Revision $Id$

## Simple talker demo that listens to std_msgs/Strings published
## to the 'chatter' topic

import rospy
from std_msgs.msg import String
from std_msgs.msg import ByteMultiArray
import sys
sys.path.append("/home/keplerc/catkin_ws/src/beginner_tutorials/scripts")
from lambda_cmd_pb2 import *


import boto3
import json
import sys
from time import sleep


import zipfile
class LambdaRuntime():
    def __init__(self, lmd_cmd):
        self.accessKey = lmd_cmd.accessKey
        self.secretKey = lmd_cmd.secretKey
        self.region = lmd_cmd.region
        self.role = lmd_cmd.role

        self.env = lmd_cmd.env
        self.bucket = lmd_cmd.bucket
        self.function_name = lmd_cmd.function_name

        self.code = lmd_cmd.code
        self.main_file_name = lmd_cmd.main_file_name
        self.zip_name = lmd_cmd.zip_name
        self.handler_name = lmd_cmd.handler_name

        self.payload = lmd_cmd.payload


    def make_zip_file(self):

        temp_file_name = self.main_file_name + ".py"
        temp_zip_name = self.zip_name
        #make zip file
        with open(temp_file_name, "w") as f:
            f.write(self.code)

        archive = zipfile.ZipFile(temp_zip_name, 'w')
        archive.write(temp_file_name, temp_file_name)
        archive.close()


    def upload_zip_to_s3(self):
        #upload code to s3
        client = boto3.client("s3", aws_access_key_id= self.accessKey, aws_secret_access_key= self.secretKey)
        client.put_object(Body=open(self.zip_name, "rb"), Bucket=self.bucket, Key=self.zip_name)

    def create_function(self):
        self.lambda_Client = boto3.client('lambda', aws_access_key_id=self.accessKey,
                       aws_secret_access_key=self.secretKey,region_name=self.region)
        response = self.lambda_Client.create_function(
                    Code={
                        'S3Bucket': self.bucket,
                        'S3Key': self.zip_name, #how can i create or fetch this S3Key
                    },
                    Description='Test automatic run lambdas using boto3',
                    FunctionName=self.function_name,
                    Handler= self.main_file_name + '.' + self.handler_name,
                    Publish=True,
                    Role=self.role,
                    Runtime=self.env,
                )
        print(response)

    def invoke_function(self):
        response = self.lambda_Client.invoke(
            FunctionName=self.function_name,
            InvocationType='RequestResponse',
            LogType='Tail',
            Payload=self.payload
        )
        print(response["Payload"].read())

    def run(self):
        self.make_zip_file()
        self.upload_zip_to_s3()
        self.create_function()
        self.invoke_function()




def callback(data):
    lambda_cmd = Lambda.FromString(bytes.fromhex(data.data))
    rospy.loginfo(rospy.get_caller_id() + 'I heard %s', lambda_cmd)
    runtime = LambdaRuntime(lambda_cmd)
    runtime.run()
    #pass

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('chatter', String, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
