#!/home/keplerc/anaconda3/bin/python
# Software License Agreement (BSD License)
#
# Copyright (c) 2008, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Willow Garage, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Revision $Id$

## Simple talker demo that published std_msgs/Strings messages
## to the 'chatter' topic

import rospy
from std_msgs.msg import String
from std_msgs.msg import ByteMultiArray
import sys
sys.path.append("./")

from lambda_cmd_pb2 import *
import codecs

def talker():
    pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)

    lambda_cmd = Lambda()

    #with open("/home/keplerc/catkin_ws/devel/kych_accessKeys.csv") as f:
    #    pubprivkey = f.read().split('\n')[1].split(",")
    lambda_cmd.accessKey = "1"#pubprivkey[0]
    lambda_cmd.secretKey = "2"#pubprivkey[1]
    lambda_cmd.region = "us-west-1"
    lambda_cmd.role = 'arn:aws:iam::998911279579:role/lambda-python-demo'

    lambda_cmd.env = 'python3.6'
    lambda_cmd.bucket = "example-com-state-store-kych"
    lambda_cmd.function_name = 'test_boto5'

    lambda_cmd.main_file_name = "hello2"
    lambda_cmd.zip_name = "function2.zip"
    lambda_cmd.handler_name = "lambda_handler"
    lambda_cmd.code = '''
import json

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    '''

    lambda_cmd.payload = '{}'

    rospy.loginfo(lambda_cmd.SerializeToString())
    pub.publish((lambda_cmd.SerializeToString().hex())) #lambda_cmd.SerializeToString())

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
